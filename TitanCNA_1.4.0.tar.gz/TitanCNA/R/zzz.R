.onLoad <- function(lib, pkg) {
    library.dynam("TitanCNA", pkg, lib)
} 
